#titulo. El 10% de la UNAM#
#Autor: Israel Garcia Solares#
#idioma: Espaqol#
#License: CC4#
install.packages("ineq")
install.packages("gender")
install.packages("genderdata", repos = "http://packages.ropensci.org")
install.packages("Rtools")
devtools::install_github("ropensci/gender")
devtools::install_github("lmullen/gender-data-pkg")
devtools::install_github("ropensci/genderdata")
install.packages("gender")
install.packages("genderdata", repos = "http://packages.ropensci.org")
install.packages("tm")
library(tm)
library(stringi)
library(ineq)
library(tidyverse)
library(plyr)
library(devtools)
library(usethis)
library(gender)
library(genderdata)
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

####A. UNAM####
####a. Profesores Carrera####
carrera<-read.csv("carrera.csv", na.strings=c("", "NA", " "), encoding="latin1") 
#descargado de http://www.transparencia.unam.mx/obligaciones/consulta/remuneracion-profesores
funcionarios<-read.csv("funcionarios.csv", na.strings=c("", "NA", " "))
funcionariosextra<-read.csv("funcionariosextra.csv", na.strings=c("", "NA", " "))
funcionariosextra<-subset(funcionariosextra, !str_detect(funcionariosextra$denominacion, "OTROS(\\s)INGRESOS"))
#descargados de http://www.transparencia.unam.mx/obligaciones/consulta/remuneracion-personal 
sni<-read.csv("sni.csv", na.strings=c("", "sin apellido Materno"), encoding="latin1")
#Padron de 2018 de la UNAM descargado de https://datos.gob.mx/busca/dataset/sistema-nacional-de-investigadores
sni2<-read.csv("sni2019.csv", na.strings=c("", "sin apellido Materno"), encoding="latin1")
#descargado de https://www.conacyt.gob.mx/images/SNI/2019/RESULTADOS_SNI_CONVOCATORIA_2019_INGRESO_O_PERMANENCIA.pdf . Esta version continene los miembros que solicitaron renovacisn para 2020#
sniresto<-read.csv("sni2018.csv", na.strings=c("", "sin apellido Materno"), encoding="latin1")
#Padron de 2018 general, con el fin de identificar los investigadores que migraron a la UNAM, decargado de https://datos.gob.mx/busca/dataset/sistema-nacional-de-investigadores
errors<-read.csv("errtrans.csv")
errors$trans<-toupper(errors$trans)
acentos<-data.frame(con=c("á", "é", "í", "ó", "ú", "ñ"), sin=c("a", "e", "i", "o", "u", "n"))
colnames(carrera)<-c("unidad", "nombre", "apellido1", "apellido2", "tipo", "bruta", "neta", "estimulos", "total")
carrera$id<-rownames(carrera)
carrera$nombre1<-str_extract(carrera$nombre, "^(\\w+)")
carrera$nombre2<-str_extract(carrera$nombre, "(?<=(\\s))(\\w+)")
funcionarios$neta<-str_replace(funcionarios$neta, "[$]", "")
funcionarios$neta<-str_replace(funcionarios$neta, "(?<=(\\d))[,](?=(\\d))", "")
funcionarios$neta<-as.numeric(as.character(funcionarios$neta))
funcionariosextra$bruta<-str_replace(funcionariosextra$bruta, "[$]", "")
funcionariosextra$bruta<-str_replace(funcionariosextra$bruta, "(?<=(\\d))[,](?=(\\d))", "")
funcionariosextra$bruta<-as.numeric(as.character(funcionariosextra$bruta))
funcionariosextra$brutas<-ifelse(funcionariosextra$periodicidad=="ANUAL", funcionariosextra$bruta/12, 
                                 ifelse(funcionariosextra$periodicidad=="SEMESTRAL", funcionariosextra$bruta/6,  
                                        funcionariosextra$bruta))
extraf<-ddply(funcionariosextra, 
              c("id"), 
              summarize, 
              estimulos=sum(brutas))
funcionarios<-left_join(funcionarios, extraf, by="id")
funcionarios$administrativo<-funcionarios$neta+funcionarios$estimulos
funcionarios$nombre1<-str_extract(funcionarios$nombre, "^(\\w+)")
funcionarios$nombre2<-str_extract(funcionarios$nombre, "(?<=(\\s))(\\w+)")
#adicionar a los profesores de carrera
carrera<-left_join(carrera, 
                   subset(funcionarios, select=c("apellido1", "apellido2", "nombre1", "administrativo", "sexo")), by=c("apellido1", "apellido2", "nombre1"))
colnames(sni)<-c("apellido1", "apellido2", "nombre", "nivel", "institucion")
sni2$nombre<-ifelse(!is.na(str_extract(lag(sni2$text), "^(\\d+)$")), sni2$text, NA)
sni2$nivel<-ifelse(!is.na(str_extract(lead(sni2$text), "^(\\d+)$")), sni2$text, NA)
sni2<-fill(sni2, nombre, .direction="down")
sni2$nivel<-ifelse(!is.na(str_extract(sni2$nivel, "CANDIDAT")), "C", 
                   ifelse(!is.na(str_extract(sni2$nivel, "(\\b)I$")), 1, 
                          ifelse(!is.na(str_extract(sni2$nivel, "(\\b)II$")), 2, 
                                 ifelse(!is.na(str_extract(sni2$nivel, "(\\b)III$")), 3, NA))))
sni3<-subset(sni2, !is.na(sni2$nivel), select=c("text","nombre", "nivel"))
sni3<-separate(sni3, nombre, into=c("apellidos", "nombre"), sep=",")
sni3$apellidos<-str_extract(sni3$nombre, ".*(?=[,])")
sni3$nombre<-str_extract(sni3$nombre, "(?<=[,](\\s)).*")
sni3$nombre<-trimws(sni3$nombre, which = "both")
sni3$apellidos<-trimws(sni3$apellidos, which = "both")
sniresto$apellidos<-paste(sniresto$apellido1, 
                          ifelse(!is.na(sniresto$apellido2), sniresto$apellido2, ""), sep=" ") %>%trimws()
sni$apellidos<-paste(sni$apellido1, 
                     ifelse(!is.na(sni$apellido2), sni$apellido2, ""), sep=" ") %>%trimws()
snitotal<-rbind(subset(sni3, select = c("nombre", "nivel", "apellidos")),
                subset(sniresto, select = c("nombre", "nivel", "apellidos")), 
                subset(sni, select = c("nombre", "nivel", "apellidos")))
for (i in 1:nrow(errors)){
  snitotal$nombre<-str_replace_all(snitotal$nombre, errors$actual[i], errors$trans[i])
  snitotal$apellidos<-str_replace_all(snitotal$apellidos, errors$actual[i], errors$trans[i])
}
for (i in 1:nrow(acentos)){
  snitotal$apellidos<-str_replace_all(tolower(snitotal$apellidos), acentos$con[i], acentos$sin[i])%>%trimws()
  snitotal$nombre<-str_replace_all(tolower(snitotal$nombre), acentos$con[i], acentos$sin[i])%>%trimws()
}
snitotal$name<-paste(snitotal$apellidos, ", ",str_extract(snitotal$nombre, "^(\\w+)"), sep="")%>%str_to_title()
snitotal<-distinct(snitotal, name, .keep_all = T)
carrera$name<-paste(carrera$apellido1, ifelse(!is.na(carrera$apellido2), paste(" ", carrera$apellido2, ", ", sep=""), ", "), 
                    str_extract(carrera$nombre, "^(\\w+)"), sep="")%>%
  str_to_title()
carrera<-left_join(carrera, subset(snitotal, select=c("name", "nivel")))
carrera$nombramiento<-str_replace_all(carrera$tipo, "^(\\w+)(\\s+)", "")
carrera$nombr<-str_to_title(str_extract(carrera$nombramiento, "EMERITO"))
carrera$nombr<-ifelse(is.na(carrera$nombr), 
                      str_to_title(str_extract(carrera$nombramiento, "EMERITO|TECNICO|PROFESOR|INVESTIGADOR")), 
                      carrera$nombr)
carrera2<-left_join(subset(carrera, select=c("id","name","unidad", "tipo", "neta", "neta", "estimulos","administrativo","apellido1","nombre1","nombre2" , "nombre","apellido2", "nombr", "sexo")),
                    subset(sni, select=c("apellido1", "apellido2", "nivel")), by=c("apellido1", "apellido2"))
carrera2<-distinct(carrera2, id, .keep_all = T)
carrera2a<-subset(carrera2, !is.na(carrera2$nivel))
carrera2b<-subset(carrera2, is.na(carrera2$nivel))
carrera2c<-left_join(subset(carrera2b, select=-c(nivel)), subset(snitotal, select=c("name", "nivel")), by="name")
carrerat<-rbind(carrera2a, carrera2c)
carreratest<-carrerat[which(!is.na(carrerat$nivel)),]
carrerat$sni<-ifelse(carrerat$nivel=="C", 8186.96,
                     ifelse(carrerat$nivel=="1", 14327.18,
                            ifelse(carrerat$nivel=="2", 18420.66,
                                   ifelse(carrerat$nivel=="3", 30701.10,0))))
carrerat$estimulos[is.na(carrerat$estimulos)]<-0
carrerat$sni[is.na(carrerat$sni)]<-0
carrerat$administrativo[is.na(carrerat$administrativo)]<-0
carrerat$total<-carrerat$neta+carrerat$estimulos+carrerat$sni+carrerat$administrativo+1255
carrerat$totalneto<-carrerat$neta+carrerat$estimulos+carrerat$sni
carrerat$unidad<-str_to_title(carrerat$unidad)
carrerat<-carrerat[order(carrerat$total),]
carrerat$orden<-1:12882

####b. adivinar genero####
carrerata<-subset(carrerat, !is.na(carrerat$sexo)) #1419 observaciones de genero del portal de la unam
carreratb<-subset(carrerat, is.na(carrerat$sexo))
carreratb$sexo<-NULL
nombres<-subset(carrerat, !is.na(carrerat$sexo),select=c("nombre1", "sexo"))
nombres<-distinct(nombres, nombre1, .keep_all = T)
carreratb<-left_join(carreratb, nombres, by="nombre1")
length(carreratb$sexo[!is.na(carreratb$sexo)]) #8960 observaciones predichas usando nombres de la misma base
carrerat<-rbind(carrerata, carreratb)
carrerata<-subset(carrerat, !is.na(carrerat$sexo)) 
carreratb<-subset(carrerat, is.na(carrerat$sexo))
carreratb$sexo<-NULL
nombres<-subset(carrerat, !is.na(carrerat$sexo),select=c("nombre1", "sexo"))
nombres<-distinct(nombres, nombre1, .keep_all = T)
colnames(nombres)<-c("nombre2", "sexo")
carreratb<-left_join(carreratb, nombres, by="nombre2")
length(carreratb$sexo[!is.na(carreratb$sexo)]) #604 observaciones predichas usando el segundo nombre de la misma base
carrerat<-rbind(carrerata, carreratb)
carrerata<-subset(carrerat, !is.na(carrerat$sexo))
carreratb<-subset(carrerat, is.na(carrerat$sexo))
carreratb$nombre1<-str_to_title(carreratb$nombre1)
carreratb$sexo<-NULL
nombres<-as.data.frame(unique(carreratb$nombre1))
colnames(nombres)<-"name"
nombres2<-gender(nombres$name, years=2000)
nombres<-left_join(nombres, subset(nombres2, select=c("name", "gender")), by="name")
colnames(nombres)<-c("nombre1", "gender")
nombres$sexo<-ifelse(nombres$gender=="female", "Femenino", 
                     ifelse(nombres$gender=="male", "Masculino", NA))
nombres$gender<-NULL
carreratb<-left_join(carreratb, nombres, by="nombre1")
length(carreratb$sexo[!is.na(carreratb$sexo)]) #1542 observaciones predichas usando el programa gender con el primer nombre
carrerat<-rbind(carrerata, carreratb)
carrerata<-subset(carrerat, !is.na(carrerat$sexo))
carreratb<-subset(carrerat, is.na(carrerat$sexo))
carreratb$nombre2<-str_to_title(carreratb$nombre2)
carreratb$sexo<-NULL
nombres<-as.data.frame(unique(carreratb$nombre2))
colnames(nombres)<-"name"
nombres2<-gender(nombres$name, years=2000)
nombres<-left_join(nombres, subset(nombres2, select=c("name", "gender")), by="name")
colnames(nombres)<-c("nombre2", "gender")
nombres$sexo<-ifelse(nombres$gender=="female", "Femenino", 
                     ifelse(nombres$gender=="male", "Masculino", NA))
nombres$gender<-NULL
carreratb<-left_join(carreratb, nombres, by="nombre2")
length(carreratb$sexo[!is.na(carreratb$sexo)])#59 observaciones predichas usando el programa gender con el segundo nombre
carrerat<-rbind(carrerata, carreratb)
carrerata<-subset(carrerat, !is.na(carrerat$sexo))
carreratb<-subset(carrerat, is.na(carrerat$sexo))
nombres<-read.csv("nombres2.csv") #clasificacion visual
carreratb$sexo<-NULL
carreratb<-left_join(carreratb, nombres, by="nombre1") #434 observaciones clasificadas visualmente
write.csv(carreratb, "carreratb.csv")
#validacion visual
nombres3<-read.csv("nombres3.csv")
nombres3<-subset(nombres3, select=c("id", "sexo"))
carreratb$sexo<-NULL
nombres3$id<-as.character((nombres3$id))
carreratb<-left_join(carreratb, nombres3, by="id")
carrerat<-rbind(carrerata, carreratb)
write.csv(carrerat, "carrerat.csv")
####c. de vuelta al resto####
carrerag<-pivot_longer(subset(carrerat, select=c("name", "orden", "neta", "estimulos", "sni","administrativo", "sexo")), c("neta", "estimulos", "sni", "administrativo"), names_to = "tipo", values_to="remuneracion")
carrerag<-subset(carrerag, carrerag$remuneracion!=0)
carrerat$decil<-with(carrerat, cut.default(floor(total), 
                                           breaks=quantile(floor(total), probs=seq(0,1, by=0.1)), 
                                           labels=c(1:10), right=T, include.lowest=T))
carreraX<-carrerat[which(carrerat$decil==10),]
carreraX$centil<-with(carreraX, cut.default(floor(total), 
                                            breaks=quantile(floor(total), probs=seq(0,1, by=0.1)), 
                                            labels=c(91:100), right=T, include.lowest=T))
carreragX<-pivot_longer(subset(carreraX, select=c("name", "orden", "neta", "estimulos", "sni", "administrativo")), c("neta", "estimulos", "sni", "administrativo"), names_to = "tipo", values_to="remuneracion")
ggplot(data=carrerag, aes(x=orden, y=remuneracion, fill=tipo))+geom_col()+
  labs(fill = "Tipo de ingreso",y="Remuneracisn total" , title="Grafico 3. Remuneracisn de profesores de carrera de menor a mayor")
ggplot(data=carrerat, aes(x=orden, y=total, fill=sexo))+geom_col()+
  labs(fill = "Ginero del nombre",y="Remuneracisn total" , title="Grafico 4. Remuneracisn de profesores de carrera de menor a mayor, por ginero")
genero<-ddply(carrerat, 
              c("sexo"), 
              summarize, 
              Remuneracion=sum(total)/length(sexo), 
              n=length(sexo))
genero$nombr<-"General"
genero2<-ddply(carrerat, 
               c("sexo", "nombr"), 
               summarize, 
               Remuneracion=sum(total)/length(sexo), 
               n=length(sexo))
genero3<-rbind(genero, genero2)
genero3<-genero3[order(genero3$sexo,genero3$nombr),]
write.csv(genero3, "genero3.csv")
ggplot(data=carreragX, aes(x=orden, y=remuneracion, fill=tipo))+geom_col()+
  labs(fill = "Tipo de ingreso",y="Remuneracisn total" , title="Grafico 1. Remuneracisn de profesores del de carrera de menor a mayor")

facultades<-ddply(carrerat, 
                  c("unidad"), 
                  summarize, 
                  remmedia=sum(total)/length(unidad))
write.csv(facultades, "facultades.csv")

####d. Profesores de Asginatura y Ayudantes####
#asumimos una distribucisn normal de horas, usando la media de acuerdo al anuario estadistico DGAPA 2020 https://www.planeacion.unam.mx/Agenda/2020/disco/#

ayudanteb<-data.frame(id=1:2986, horas=0, nombr="AyB", tipo="AYUDANTE")
ayudantea<-data.frame(id=1:1200, horas=0, nombr="AyA", tipo="AYUDANTE")
asignb<-data.frame(id=1:504, horas=0 , nombr="B", tipo="ASIGNATURA")
asigna<-data.frame(id=1:(4312-nrow(asignb)), horas=0, nombr="A", tipo="ASIGNATURA")
while((mean(ayudantea$horas)>=8.48)|(mean(ayudantea$horas)<8.47)){
  set.seed(sample(1:1500, 1))
  for (i in 1:nrow(ayudantea)){
    x<-0
    while(x<2){
      x<-rnorm(n=1, mean=10173/1200, sd=1.7)  
    }
    ayudantea$horas[i]<-x
  }
}
while((mean(ayudanteb$horas)>=11.37)|(mean(ayudanteb$horas)<11.36)){
  set.seed(sample(1:1500, 1))
  for (i in 1:nrow(ayudanteb)){
    x<-0
    while(x<2){
      x<-rnorm(n=1, mean=33933/2986, sd=1.7)  
    }
    ayudanteb$horas[i]<-x
  }
}
while((mean(asignb$horas)>=20.66)|(mean(asignb$horas)<20.65)){
  #  set.seed(sample(1:1500, 1))
  for (i in 1:nrow(asignb)){
    x<-0
    while(x<2){
      x<-rnorm(n=1, mean=20.65062, sd=2)  
    }
    asignb$horas[i]<-x
  }
}
while((mean(asigna$horas)>=12.26)|(mean(asigna$horas)<12.25)){
  #set.seed(sample(1:1500, 1))
  for (i in 1:nrow(asigna)){
    x<-0
    while(x<2){
      x<-rnorm(n=1, mean=12.25898, sd=2)  
    }
    asigna$horas[i]<-x
  }
}
precarisimos<-rbind(ayudantea, ayudanteb, asigna, asignb)
precarisimos$id<-paste(precarisimos$nombr, precarisimos$id, sep="")
precarisimos$horas<-round(precarisimos$horas, digits = 1)
precarisimos<-precarisimos[order(precarisimos$horas),]
precarisimos$orden<-1:nrow(precarisimos)
precarisimos$ant<-ifelse(precarisimos$orden<1214, 1, 
                         ifelse(precarisimos$orden<2428, 4, 
                                ifelse(precarisimos$orden<3642, 7, 
                                       ifelse(precarisimos$orden<4856, 10, 
                                              ifelse(precarisimos$orden<6070, 13, 
                                                     ifelse(precarisimos$orden<7284, 16, 19))))))

write.csv(precarisimos, "precarisimos.csv", row.names = F)

####e. La distribucion final####
genero<-read.csv("genero.csv")
genero$NumeroEmpleado<-as.character(genero$NumeroEmpleado)
#precarios<-read.csv("precarisimos.csv", encoding="utf-8")
precarios<-read.csv("asignatura2.csv", encoding="latin1")
carrerat<-read.csv("Carrerat.csv", encoding="latin1")
carrerat$X<-NULL
precarios$name<-"Anonime"
#precarios$nombr<-precarios$CategoriaEspecifica.1
precarios$nombr<-ifelse(str_detect(precarios$nombr, "AyA"), "Ayudante A", 
                        ifelse(str_detect(precarios$nombr, "AyB"), "Ayudante B", 
                               ifelse(str_detect(precarios$nombr, "B"), "Asignatura B", "Asignatura A")))
precarios$neta<-precarios$sueldo.base
precarios$estimulos<-precarios$total-precarios$neta
precarios$sni<-0
precarios$administrativo<-0
precarios<-left_join(precarios, genero, by="NumeroEmpleado")
precarios$sexo<-precarios$Genero
precarios$apellido1<-NA
precarios$nombre<-precarios$name
precarios$apellido2<-NA
precarios$horas<-precarios$TotalHorasSemana
precarios$horas<-ifelse(precarios$horas<1, 1, precarios$horas)
carrerat$horas<-40
todos<-rbind(
  subset(carrerat, select=c("name" , "nombre","apellido1", "apellido2", "nombr", "neta", "sexo","estimulos", "sni", "administrativo", "horas","total")), 
  subset(precarios, select=c("name" , "nombre","apellido1", "apellido2","nombr", "neta", "sexo","estimulos", "sni", "administrativo", "horas","total"))
)
todos<-todos[order(todos$total),]
todos$orden<-1:nrow(todos)
todos$decil<-with(todos, cut.default(floor(total), 
                                     breaks=quantile(floor(total), probs=seq(0,1, by=0.1)), 
                                     labels=c(1:10), right=T, include.lowest=T))
todos$nombramiento<-ifelse(todos$administrativo!=0, "Funcionario", todos$nombr)
todos$horas<-ifelse(todos$nombramiento=="Funcionario", 48, todos$horas)
todos$contrato<-todos$total/todos$horas
todosg<-pivot_longer(subset(todos, select=c("name", "orden", "neta", "nombr","estimulos", "sni", "administrativo")), c("neta", "estimulos", "sni", "administrativo"), names_to = "tipo", values_to="remuneracion")
todosg<-subset(todosg, todosg$remuneracion!=0)
unoporcieng<-subset(todosg, todosg$orden>33459.3)
unoporcien<-subset(todos, todos$orden>33459.3)
tablaingreso<-ddply(todos, 
                    c("decil"), 
                    summarize, 
                    ingreso=sum(total))
Gini(todos$total)
sum(unoporcien$total)-sum(todos$total[which(todos$orden<12776)])
mean(todos$total[which(todos$orden>33459.3)])
mean(todos$total[which(todos$orden<11)])
mean(todos$total[which(todos$orden>33459.3)])/mean(todos$total[which(todos$orden<11)])
sobresalario<-todos[which(todos$total>111990),]
bajosalario<-todos[which(todos$total<(2.03577*3746)),]
sobresalario$sobre<-sobresalario$total-111990
sum(sobresalario$sobre)
bajosalario$bajo<-(2.0357*3746)-bajosalario$total
sum(bajosalario$bajo)
todos$proyectado<-ifelse(todos$total<(2.036*3746), 2.036*3746, 
                         ifelse(todos$total>111990, 111990, todos$total))
Gini(todos$proyectado)/Gini(todos$total)
todosc<-todos[order(todos$contrato),]
todosc$orden<-1:nrow(todosc)

todosg$tipo<-str_to_title(todosg$tipo)
ggplot(data=todosg, aes(x=orden, y=remuneracion, fill=tipo))+geom_col()+
  scale_y_continuous(breaks=c(0,5000,10000, 50000, 100000, 150000, 200000, 250000))+
  labs(fill = "Tipo de ingreso",y="Remuneracisn total" , title="Grafico 7. Remuneracisn de profesores de menor a mayor")
ggplot(data=todos, aes(x=orden, y=horas, fill=nombramiento))+geom_col()+ 
  scale_y_continuous(breaks=c(0,5000,10000, 50000, 100000, 150000, 200000, 250000))+
  labs(fill = "Nombramiento",y="Remuneracisn total" , title="Grafico 8. Remuneracisn de profesores de menor a mayor")
ggplot(data=todosc, aes(x=orden, y=contrato, fill=nombramiento))+geom_col()+ 
  scale_y_continuous(breaks=c(0,1000,2000, 3000, 40000, 5000, 6000))+
  labs(fill = "Nombramiento",y="Remuneraci?n por hora/contrato" , title="Grafico 8. Remuneraci?n por hora-contrato de profesores de menor a mayor")

ggplot(data=todos, aes(x=orden, y=proyectado, fill=nombramiento))+geom_col()+ 
  scale_y_continuous(breaks=c(0,5000,10000, 50000, 100000, 150000, 200000, 250000))+
  labs(fill = "Nombramiento",y="Remuneracisn total" , title="Grafico 9. Remuneracisn de profesores de menor a mayor con limites")

ggplot(data=unoporcieng, aes(x=orden, y=remuneracion, fill=tipo))+geom_col()+
  labs(fill = "Tipo de ingreso",y="Remuneracisn total" , title="Grafico 4. Remuneracisn de profesores del 1%")


ggplot(data=todosg[which(todosg$tipo!="Administrativo"),], aes(x=orden, y=remuneracion, fill=tipo))+geom_col()+
  scale_y_continuous(breaks=c(0,5000,10000, 50000, 100000, 150000, 200000, 250000))+
  labs(fill = "Tipo de ingreso",y="Remuneracisn total" , title="Grafico 7. Remuneracisn de profesores de menor a mayor")


todos2<-todosg[which(todosg$tipo!="Administrativo"),]
todos$nombre<-str_extract(todos$name, "(?<=[,](\\s)).*")
todos$apellido1<-str_extract(todos$name, "^(\\w+)")
todos$apellido2<-str_extract(todos$name, "(?<=(\\w)(\\b)).*(?=[,])")
write.csv(tablaingreso, "decilesingreso.csv", row.names = F)
write.csv(todos, "todes.csv", row.names = F)
write.csv(todosc, "todesc.csv", row.names = F)


####B. Tabla general####
general<-read.csv("general.csv", na.strings=c("", " ", NA, "NA", "-", ".", 0), encoding="latin1")
extras<-read.csv("extras.csv", na.strings=c("", " ", NA, "NA", "-", ".", 0), encoding="latin1")
errors<-read.csv("errtrans.csv", encoding="latin1")
errors$trans<-toupper(errors$trans)
acentos<-data.frame(con=c("á", "é", "í", "ó", "ú", "ñ"), sin=c("a", "e", "i", "o", "u", "n"))
unic<-data.frame(unique(extras$periodicidad))
extras<-subset(extras, extras$neto!=0)
extras$neto<-abs(extras$neto)
extras$mensual<-ifelse(str_detect(tolower(extras$periodicidad),"quinquen"), extras$neto/60, 
                       ifelse(str_detect(tolower(extras$periodicidad),"anual|año|vacaci"), extras$neto/12,
                              ifelse(str_detect(tolower(extras$periodicidad),"semes"), extras$neto/6,
                                     ifelse(str_detect(tolower(extras$periodicidad),"cuatri|tres(\\s)veces"), extras$neto/4, 
                                            ifelse(str_detect(tolower(extras$periodicidad),"(\\b)trimes"), extras$neto/3,
                                                   ifelse(str_detect(tolower(extras$periodicidad),"quince|catorce"), extras$neto*2,
                                                          ifelse(str_detect(tolower(extras$periodicidad),"evento|eventual"), extras$neto*0,
                                                          extras$neto)))))))
textra<-ddply(extras, 
              c("id", "Universidad"), summarize, 
              menst=sum(mensual, na.rm=T))
colnames(general)<-c("id", "ejercicio", "cargo", "nombre", "apellido1", "apellido2",
                     "sexo", "neto", "Universidad")
general<-left_join(general, textra, by=c("id", "Universidad"))
general<-general[order(general$apellido1, general$apellido2, general$nombre),]
general$prof<-ifelse(str_detect(tolower(general$cargo), 
                                "prof|acade|rector|inves|titular|asoci|catedr|operativo|presidente|secretario|docent"), 
                     "academ", NA)
general<-general[which(!is.na(general$nombre)&!is.na(general$apellido1)),]
general$apellido1<-ifelse(is.na(general$apellido1)&!is.na(general$apellido2), general$apellido2, general$apellido1)
general$apellido2<-ifelse(is.na(general$apellido1)&!is.na(general$apellido2), NA, general$apellido2)
for (i in 1:nrow(errors)){
  general$apellido1<-str_replace_all(toupper(general$apellido1), errors$actual[i], errors$trans[i])%>%trimws()
  general$apellido2<-str_replace_all(toupper(general$apellido2), errors$actual[i], errors$trans[i])%>%trimws()
  general$nombre<-str_replace_all(toupper(general$nombre), errors$actual[i], errors$trans[i])%>%trimws()
}
for (i in 1:nrow(acentos)){
  general$apellido1<-str_replace_all(tolower(general$apellido1), acentos$con[i], acentos$sin[i])%>%trimws()
  general$apellido2<-str_replace_all(tolower(general$apellido2), acentos$con[i], acentos$sin[i])%>%trimws()
  general$nombre<-str_replace_all(tolower(general$nombre), acentos$con[i], acentos$sin[i])%>%trimws()
}
general$apellidos<-paste(general$apellido1, 
                         ifelse(!is.na(general$apellido2), general$apellido2, ""), sep=" ") %>%
  trimws()%>%str_to_title()
general$name<-paste(general$apellidos, ", ", str_extract(general$nombre, "^(\\w+)"), sep="")%>%
  trimws()%>%str_to_title()
general<-general[order(general$name),]
for (i in 2:nrow(general)){
  if(is.na(general$prof[i])&!is.na(general$prof[i-1])&(general$name[i]==general$name[i-1])){
    general$prof[i]<-general$prof[i-1]
  } else{
    general$prof[i]<-general$prof[i]
  }
}
academ<-general[which(!is.na(general$prof)),]
academ$neto<-ifelse(str_detect(academ$Universidad, "UAM"), academ$neto/6, 
                    ifelse(str_detect(academ$Universidad, "ayarit"), academ$neto/3, 
                           ifelse(str_detect(academ$Universidad, "Sonora"), 
                                  academ$neto/3, academ$neto)))
academ$neto<-abs(academ$neto)
academ$menst<-abs(academ$menst)
academ$name<-str_to_title(academ$name)
sni<-read.csv("sni.csv", na.strings=c("", "sin apellido Materno"), encoding="latin1")
#Padron de 2018 de la UNAM descargado de https://datos.gob.mx/busca/dataset/sistema-nacional-de-investigadores
sni2<-read.csv("sni2019.csv", encoding="latin1")
#descargado de https://www.conacyt.gob.mx/images/SNI/2019/RESULTADOS_SNI_CONVOCATORIA_2019_INGRESO_O_PERMANENCIA.pdf . Esta version continene los miembros que solicitaron renovacisn para 2020#
sniresto<-read.csv("sni2018.csv", encoding="latin1")
#Padron de 2018 general, con el fin de identificar los investigadores que migraron a la UNAM, decargado de https://datos.gob.mx/busca/dataset/sistema-nacional-de-investigadores
colnames(sni)<-c("apellido1", "apellido2", "nombre", "nivel", "institucion")
sni2$nombre<-ifelse(!is.na(str_extract(lag(sni2$text), "^(\\d+)$")), sni2$text, NA)
sni2$nivel<-ifelse(!is.na(str_extract(lead(sni2$text), "^(\\d+)$")), sni2$text, NA)
sni2<-fill(sni2, nombre, .direction="down")
sni2$nivel<-ifelse(!is.na(str_extract(sni2$nivel, "CANDIDAT")), "C", 
                   ifelse(!is.na(str_extract(sni2$nivel, "(\\b)I$")), 1, 
                          ifelse(!is.na(str_extract(sni2$nivel, "(\\b)II$")), 2, 
                                 ifelse(!is.na(str_extract(sni2$nivel, "(\\b)III$")), 3, NA))))
sni3<-subset(sni2, !is.na(sni2$nivel), select=c("text","nombre", "nivel"))
sni3<-separate(sni3, nombre, into=c("apellidos", "nombre"), sep=",")
sni3$nombre<-trimws(sni3$nombre, which = "both")
sni3$apellidos<-trimws(sni3$apellidos, which = "both")
sniresto$apellidos<-paste(sniresto$apellido1, 
                          ifelse(!is.na(sniresto$apellido2), sniresto$apellido2, ""), sep=" ") %>%trimws()
sni$apellidos<-paste(sni$apellido1, 
                     ifelse(!is.na(sni$apellido2), sni$apellido2, ""), sep=" ") %>%trimws()
snitotal<-rbind(subset(sni3, select = c("nombre", "nivel", "apellidos")),
                subset(sniresto, select = c("nombre", "nivel", "apellidos")), 
                subset(sni, select = c("nombre", "nivel", "apellidos")))
for (i in 1:nrow(errors)){
  snitotal$nombre<-str_replace_all(snitotal$nombre, errors$actual[i], errors$trans[i])
  snitotal$apellidos<-str_replace_all(snitotal$apellidos, errors$actual[i], errors$trans[i])
}
for (i in 1:nrow(acentos)){
  snitotal$apellidos<-str_replace_all(tolower(snitotal$apellidos), acentos$con[i], acentos$sin[i])%>%trimws()
  snitotal$nombre<-str_replace_all(tolower(snitotal$nombre), acentos$con[i], acentos$sin[i])%>%trimws()
}
snitotal$name<-paste(snitotal$apellidos, ", ",str_extract(snitotal$nombre, "^(\\w+)"), sep="")%>%str_to_title()
snitotal<-distinct(snitotal, name, .keep_all = T)
unis2<-distinct(academ, name, neto, .keep_all = T)
unis2$name<-str_replace_all(unis2$name, "(\\s),", ",")%>%trimws()
unis2<-left_join(subset(unis2, select=c("Universidad","id","name","prof", "apellido1", "apellido2", "nombre", "name", "neto", "menst", "sexo")),
                 subset(snitotal, select=c("name", "nivel")), by=c("name"))
unis2$estsni<-ifelse(unis2$nivel=="C", 8186.96,
                     ifelse(unis2$nivel=="1", 14327.18,
                            ifelse(unis2$nivel=="2", 18420.66,
                                   ifelse(unis2$nivel=="3", 30701.10,0))))
unis2$neto<-ifelse(is.na(unis2$neto), 0, unis2$neto)
unis2$estimulos<-ifelse(is.na(unis2$menst), 0, unis2$menst)
unis2$sni<-ifelse(is.na(unis2$estsni), 0, unis2$estsni)
unis2$total<-unis2$neto+unis2$estimulos+unis2$sni
write.csv(unis2, "academicosnacional.csv", row.names = F)


####C. Juntar####
todos<-read.csv("todes.csv")
general<-read.csv("academicosnacional.csv")
todos$Universidad<-"UNAM"
todos$id<-rownames(todos)
todos$neto<-todos$neta+todos$administrativo
general$estimulos<-general$menst
general$sni<-general$estsni
todos$fuente<-"UNAM"
general$fuente<-general$Universidad
general<-distinct(general, name, fuente, neto, .keep_all=T)
nacional<-rbind(
  subset(general, select=c("id", "nombre", "apellido1", "apellido2", "name", "sexo", "neto", "estimulos", "sni","total", "fuente")),
  subset(todos, select=c("id", "nombre", "apellido1", "apellido2", "name", "sexo", "neto", "estimulos", "sni","total", "fuente")))
nacional$name<-ifelse(is.na(nacional$apellido1), "Anonime", 
                      nacional$name)%>%trimws()
for(i in 1:10){
  nacional$name<-str_replace_all(nacional$name, "(\\s)(?=[,])|(\\b)NA(\\b)|(\\s)$|[0-9]|^(\\s)|^[:punct:]", "")  
}
nacional$name<-str_to_title(nacional$name)
tablenames<-count(nacional, "name")
nacional<-left_join(nacional, tablenames)
nacional$name<-ifelse((nacional$freq>1)&(nacional$name!="Anonime"), 
                      str_replace(nacional$name, "(?<=,(\\s)).*", trimws(nacional$nombre)), 
                      nacional$name) %>% str_to_title()
nacional$count<-NULL
nacional$apellido1<-str_to_title(nacional$apellido1)
nacional$apellido2<-str_to_title(nacional$apellido2)
nacional$nombre<-str_to_title(nacional$nombre)
nacional$neto<-ifelse(is.na(nacional$neto), 0, nacional$neto)
nacional$estimulos<-ifelse(is.na(nacional$estimulos), 0, nacional$estimulos)
nacional$sni<-ifelse(is.na(nacional$sni), 0, nacional$sni)
nacionalt<-ddply(nacional[which(nacional$name!="Anonime"),], c("name"), 
                 summarize, 
                 neto=sum(neto), 
                 estimulos=sum(estimulos),
                 sni=mean(sni))
afiliacion<-subset(nacional[which(nacional$name!="Anonime"),], select=c("name", "fuente"))
afiliacion<-distinct(afiliacion, name, .keep_all = T)
sexo<-subset(nacional[which(nacional$name!="Anonime"),], select=c("name", "sexo"))
nacionalt<-left_join(nacionalt, afiliacion)
nacionalt<-left_join(nacionalt, sexo)
nacionalt<-distinct(nacionalt, .keep_all = T)
nacionalnan1<-nacional[which(nacional$name=="Anonime"),]
nacionalnan1$sni<-0
nacionalt2<-rbind(subset(nacionalt, select=c("name","neto", "estimulos","sni", "sexo","fuente")), 
                  subset(nacionalnan1, select=c("name","neto", "estimulos", "sni", "sexo","fuente")))
nacionalt2$total<-nacionalt2$neto+nacionalt2$sni+nacionalt2$estimulos
write.csv(nacionalt2, "nacional.csv", row.names = F, encoding="latin1")
unis<-nacionalt2
abbrev<-read.csv("abrevuni.csv", encoding="latin1")
unis<-left_join(unis, abbrev)
unis$fuente<-unis$Universidad
unis<-subset(unis, select=c("name", "fuente", "sexo", "neto", "estimulos", "sni","total"), 
             unis$total>100&unis$neto>100)
unis2<-pivot_longer(subset(unis, select=c("fuente", "neto", "estimulos", "sni","total")),
                           cols=c("neto", "estimulos", "sni","total"), 
                    names_to="remuneracion", values_to = "monto")
medias<-ddply(unis2[which(unis2$remuneracion!="total"),], 
              c("fuente", "remuneracion"), summarize, 
              montomedio=mean(monto))
mediasb<-ddply(unis2[which(unis2$remuneracion=="total"),], 
               c("fuente"), summarize, 
               montotot=mean(monto))
mediasb<-mediasb[order(mediasb$montotot),]
mediasb$order<-1:nrow(mediasb)
mediasb$montotot<-NULL
medias<-left_join(medias, mediasb)
ggplot(data=medias, 
       aes(x=reorder(fuente, order), 
                        y=montomedio, fill=remuneracion))+geom_col()+
  labs(fill = "Tipo de ingreso",x="Universidad", y="Remuneracion total")+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
unis3<-pivot_longer(subset(unis, select=c("sexo", "neto", "estimulos", "sni","total"), !is.na(unis$sexo)),
                    cols=c("neto", "estimulos", "sni","total"), 
                    names_to="remuneracion", values_to = "monto")
medias2<-ddply(unis3[which(unis2$remuneracion!="total"),], 
              c("sexo", "remuneracion"), summarize, 
              montomedio=mean(monto))
medias2<-medias2[which(!is.na(medias2$sexo)),]
ggplot(data=medias2, 
       aes(x=sexo, 
           y=montomedio, fill=remuneracion))+geom_col()+
  labs(fill = "Tipo de ingreso",x="Universidad", y="Remuneracion total" , title="Grafico. Remuneraciones medias por genero")+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
1-sum(medias2$montomedio[which(medias2$sexo=="Femenino")])/sum(medias2$montomedio[which(medias2$sexo=="Masculino")])
ginis<-ddply(unis, c("fuente"), summarize, 
             gini=Gini(total))
ginis[nrow(ginis)+1,]<-c("Nacional", Gini(unis$total))
ginis$gini<-as.numeric(ginis$gini)
ggplot(data=ginis, 
       aes(x=reorder(fuente, gini), y=gini))+geom_col()+
  labs(x="Universidad", y="Gini" , title="Grafico. Gini por universidad")+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))
pnt<-count(unis, c("fuente"))
ggplot(pnt, aes(x=reorder(fuente, freq), y=freq))+geom_col()+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
  labs(x="Fuente", y="Frecuencia")
library(tidyverse)
unis4<-ddply(unis, 
             "fuente", mutate,
             ra=as.numeric(rank(total, ties.method="first")))
unis4<-ddply(unis4, 
             "fuente", mutate, 
             centil=cut.default(floor(ra), 
                                     breaks=quantile(floor(ra), probs=seq(0,1, by=0.01)),
                                     labels=c(1:100), right=T, include.lowest=T))
top<-unis4[which(unis4$centil==100),]
top<-pivot_longer(subset(top, select=c("fuente", "neto", "estimulos", "sni")),
                    cols=c("neto", "estimulos", "sni"), 
                    names_to="remuneracion", values_to = "monto")
topm<-ddply(top[which(top$remuneracion!="total"),], 
           c("fuente", "remuneracion"), summarize, 
           montomedio=mean(monto))
topm2<-ddply(top[which(top$remuneracion!="total"),], 
             c("remuneracion"), summarize, 
             montototal=sum(monto))
ggplot(data=topm, 
       aes(x=reorder(fuente,montomedio), 
           y=montomedio, fill=remuneracion))+geom_col()+
  labs(fill = "Tipo de ingreso",x="Universidad", y="Remuneracion total media")+
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

write.csv(unis2, "unis3.csv")
write.csv(ginis, "ginis2.csv")
